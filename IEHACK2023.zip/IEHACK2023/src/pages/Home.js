import React from "react";
import { useNavigate } from "react-router-dom";
import logo from '../images/hypotize.gif';
import { setSessionStorage } from "../servicse/utils";

const Home = () => { 


    const navi = useNavigate();
    const submitPlayer = (ev) => {
        ev.preventDefault();

        var player = document.querySelector("#player-name").value;

        if(player.length > 2){
            navi('/choose-player');
            setSessionStorage('playername', player);
            document.querySelector('audio').play();
        } else {
            alert("Add Player Name")
        }

    }

    return(
        <div className="container">
            <div className="logo">
                <img src={logo} />
            </div>
            <h3 className="heading-title">PARTIAL DEMOCRACY</h3>
            <label className="switch">
                    <input type="checkbox" />
                    <span className="slider">Free Media</span>
                </label>
            <div className="add-player">
                <form onSubmit={submitPlayer}>
                    <input type="text" placeholder="Add Player Name" id="player-name"/>
                    <input type="submit" value="SUBMIT"/>
                </form>
            </div>
        </div>
    )
}

export default Home;