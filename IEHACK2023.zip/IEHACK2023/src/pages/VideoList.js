import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const VideoList = () => {
    
    const navi = useNavigate();

    let counting = 0;
    const videoUrl = [
        "https://www.youtube.com/embed/hua6NlwYkxk?autoplay=1&mute=0&showinfo=0&controls=0",
        "https://www.youtube.com/embed/GNy2TooIB38?autoplay=1&mute=0&showinfo=0&controls=0",
        "https://www.youtube.com/embed/55T30G8T95E?autoplay=1&mute=0&showinfo=0&controls=0",
    ];

    const videoUrl2 = [
        "https://www.youtube.com/embed/hua6NlwYkxk?autoplay=1&mute=0&showinfo=0&controls=0",
        "https://www.youtube.com/embed/GNy2TooIB38?autoplay=1&mute=0&showinfo=0&controls=0",
        "https://www.youtube.com/embed/55T30G8T95E?autoplay=1&mute=0&showinfo=0&controls=0",
    ];

    const myInterval = setInterval(myTimer, 50000);
    
   
    function myTimer() {
        document.querySelector('iframe').setAttribute('src', videoUrl[counting+1])
       counting = counting + 1;
        if(counting == 3){
            clearInterval(myInterval)
            document.querySelector('audio').play()
            navi('/voting');
        }
    }



    useEffect(() => {
        document.querySelector('iframe').setAttribute('src', videoUrl[counting])
    })

    return (
        <div className="container">
            <ul className="video-list-container">
                <li>
                    <iframe width="100%" height="476" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen></iframe>
                </li>
            </ul>
        </div>
    )
}

export default VideoList;

