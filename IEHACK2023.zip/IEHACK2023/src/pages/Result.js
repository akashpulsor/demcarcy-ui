import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Result = () => {
    

    return (
        <div className="container">
            <ul className="video-list-container">
                <li>
                <iframe width="100%" height="476" src="https://www.youtube.com/embed/WwzMTSucHPY?autoplay=1&mute=0&showinfo=0&controls=0" title="bohot manhush lag rahe ho meme dilog// download link on discription" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </li>
            </ul>
        </div>
    )
}

export default Result;

