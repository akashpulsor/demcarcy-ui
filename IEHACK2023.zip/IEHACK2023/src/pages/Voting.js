import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import modi from '../images/modiji.png';


const Voting = () => {
    
    const navi = useNavigate();

    const seeResult = () => {
        document.querySelector('audio').pause()
        navi('/result')
    }


    const seeResult1 = () => {
        document.querySelector('audio').pause()
        navi('/result1')
    }

    return(
        <div className="container">
            
            <ul className="player-list">
                <li className="remove-link">
                    <img src={modi}  alt="Modi" name="Modi"/>
                </li>
            </ul>

            <div className="voting-box">
                <div className="vote" onClick={seeResult1}>Vote</div>
                <div className="vote" onClick={seeResult}>Reject</div>
            </div>
            
        </div>
    )
}

export default Voting;