import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import modi from '../images/modiji.png';
import rahul from '../images/rahul.png'
import kejariwal from '../images/kejri.png'

const ChoosePlayer = () => {
    
    const navi = useNavigate();
    const gameStart = () => {
         document.querySelector('audio').pause();
        navi('/reels')
    }

    const [selectItem, setSelectItem] = useState('Modi');

    const itemSelect = (ev) =>{
        setSelectItem(ev.target.getAttribute('alt'))
    }

    return(
        <div className="container">
            
            <ul className="player-list">
                <li className={selectItem == "Modi" ? "selected" : null}>
                    <img src={modi}  alt="Modi" name="Modi" onClick={itemSelect}/>
                </li>

                <li className={selectItem == "Rahul" ? "selected" : null}>
                    <img src={rahul} alt="Rahul" name="Rahul" onClick={itemSelect}/>
                </li>
                
                <li className={selectItem == "Kejariwal" ? "selected" : null}>
                    <img src={kejariwal} alt="Kejariwal" name="Kejariwal" onClick={itemSelect}/>
                </li>
            </ul>

            <div className="play-now" onClick={gameStart}>
                Play
            </div>
            
        </div>
    )
}

export default ChoosePlayer;