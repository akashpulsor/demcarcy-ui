import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const ResultOne = () => {
    

    return (
        <div className="container">
            <ul className="video-list-container">
                <li>
                <iframe width="100%" height="476" src="https://www.youtube.com/embed/ZtF830E3f98?autoplay=1&mute=0&showinfo=0&controls=0" title="AGAR HUM KARE TOH KARE KYA BOLE TOH BOLE KYA WAH MODI JI WAH" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </li>
            </ul>
        </div>
    )
}

export default ResultOne;

