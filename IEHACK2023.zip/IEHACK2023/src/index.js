import React from 'react';
import ReactDOM from 'react-dom/client';
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import Home from './pages/Home';
import './index.css';
import ChoosePlayer from './pages/ChoosePlayer';
import VideoList from './pages/VideoList';
import sound from './audio/Malgudi Days - Bgm.mp3';
import Voting from './pages/Voting';
import Result from './pages/Result';
import ResultOne from './pages/ResultOne'

const router = createBrowserRouter([
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/choose-player",
    element: <ChoosePlayer />,
  },
  {
    path: "/reels",
    element: <VideoList />,
  },
  {
    path: "/voting",
    element: <Voting />,
  },
  {
    path: "/result",
    element: <Result />
  },
  {
    path: "/result1",
    element: <ResultOne />
  }
]);

const root = ReactDOM.createRoot(document.getElementById('root'));
ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <div>
      <RouterProvider router={router} />
      <audio autoPlay oop>
       <source src={sound} type="audio/mpeg"/>
      </audio>
    </div>
  </React.StrictMode>
);
